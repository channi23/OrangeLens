# TruthLens - AI-Powered Fact Verification

A Progressive Web App that provides one-tap fact verification from any mobile app via the system Share sheet, with transparent AI explanations and verified citations.

## 🎯 USP
One-tap fact verification from any mobile app via the system Share sheet, with transparent AI explanations and verified citations. Powered by Google Cloud for scalability, cost-efficiency, and transparency.

## 🏗️ Architecture

```
TruthLens/
├── app/                    # Progressive Web App (React)
│   ├── src/               # React source code
│   ├── public/             # Static assets (includes service worker)
│   ├── manifest.json       # PWA manifest
│   └── public/sw.js        # Service worker
├── api/                    # Backend API (Cloud Run)
│   ├── main.py            # FastAPI application
│   ├── requirements.txt   # Python dependencies
│   └── Dockerfile        # Container configuration
├── infra/                  # Infrastructure configs
│   ├── terraform/         # Terraform configurations
│   ├── cloudbuild.yaml   # Cloud Build config
│   └── api-gateway.yaml  # API Gateway spec
├── scripts/               # Deployment scripts
└── docs/                  # Documentation
```

## 🚀 Quick Start

### Prerequisites
- Node.js 16+
- Python 3.11+
- Google Cloud SDK
- GCP Project with billing enabled

### Development Setup
```bash
# Clone the repository
git clone https://github.com/channi23/OrangeLens.git
cd OrangeLens

# Setup your specific project (orange-lens-472108)
./scripts/setup-orange-lens.sh

# Start development servers
./scripts/start-dev.sh
```

### Production Deployment
```bash
# Deploy to Google Cloud
./scripts/deploy.sh
```

## 📱 Features
- ✅ **One-tap verification** from any app via Share sheet
- ✅ **Text and image verification** using AI
- ✅ **Fast/Deep verification modes**
- ✅ **Multi-language support** (English, Hindi, Tamil)
- ✅ **Offline support** with service worker
- ✅ **Real-time metrics** (latency, cost)
- ✅ **Transparent AI explanations**
- ✅ **Verified citations** from fact-check databases

## 🔧 Tech Stack
- **Frontend**: React PWA, Service Worker, Web Share Target
- **Backend**: Cloud Run, API Gateway, Vertex AI Gemini
- **Data**: BigQuery, Cloud Storage, Google Fact Check API
- **Security**: Secret Manager, API Keys/JWT
- **Monitoring**: Cloud Logging, Cloud Monitoring
- **Infrastructure**: Terraform, Cloud Build

## 📊 Cost Estimate
~$200/month for 50k queries (covered by GCP credits)

## 🏃‍♂️ Getting Started

### 1. Setup Development Environment
```bash
./scripts/setup-dev.sh
```

### 2. Run Locally (Backend + Frontend)
Follow these steps to run the API and PWA locally for development.

#### Backend API (FastAPI)
1) Configure environment
```bash
cd api
cp config.env.example .env
# Edit .env and set at least:
# GOOGLE_CLOUD_PROJECT=local-dev
# GOOGLE_CLOUD_LOCATION=us-central1
# GEMINI_MODE=vertex
# GEMINI_MODEL=gemini-2.5-flash-lite
# SERPER_API_KEY=YOUR_SERPER_API_KEY   # optional news search fallback
# GEMINI_API_KEY=YOUR_GEMINI_API_KEY  # only needed when using Express REST locally
# FACT_CHECK_API_KEY=YOUR_FACT_CHECK_API_KEY  # optional (enables deep fact checks)
```
2) Install and run
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8080
```
3) Quick tests
```bash
# Fast (text)
curl -X POST http://localhost:8080/v1/verify-test \
  -H 'Content-Type: application/json' \
  -d '{"text":"The Earth orbits the Sun.","language":"en"}'

# Image (multipart, unauthenticated for dev)
curl -X POST http://localhost:8080/v1/verify-image-test \
  -F 'text=What is shown?' -F 'language=en' -F 'image=@/path/to/photo.jpg'
```

Notes
- Gemini requests default to Vertex Gemini 2.5 Flash Lite (service account auth). Set `GEMINI_MODE=vertex` unless you specifically need the Express REST API.
- Evidence retrieval first queries Google Fact Check Tools; if nothing is found, it falls back to a news search (Serper.dev) when `SERPER_API_KEY` is configured.
- Deep checks (or low confidence) can call Google Fact Check API when `FACT_CHECK_API_KEY` is provided.

#### Frontend PWA (React)
1) Configure environment
```bash
cd app
echo "REACT_APP_API_URL=http://localhost:8080" > .env
# Optional only if using authenticated /v1/verify locally:
# echo "REACT_APP_API_KEY=YOUR_TRUTHLENS_API_KEY" >> .env
```
2) Start development server
```bash
npm install
npm start
```
3) Mobile Share Target
- Install the PWA to your device (Add to Home Screen).
- Share text or an image to TruthLens; the app opens with the text prefilled and image attached.
- Image flows use `POST /v1/verify-image-test` locally (no API key needed).

### 3. Test the API (optional)
```bash
./scripts/test-api.sh
```
> This helper script requires `jq` for pretty-printing JSON. Install it via `brew install jq` (macOS) or your distribution's package manager.

## 🚀 Deployment

### Prerequisites
1. GCP Project with billing enabled
2. gcloud CLI installed and authenticated
3. Required APIs enabled

### Deploy to Production
```bash
# Set your project ID (already configured)
export PROJECT_ID="orange-lens-472108"

# Deploy everything
./scripts/deploy.sh
```

### Manual Deployment Steps
1. **Enable APIs**: Run the deployment script
2. **Create Infrastructure**: Deploy Terraform configurations
3. **Build & Deploy API**: Cloud Build + Cloud Run
4. **Deploy PWA**: Build and deploy to hosting service
5. **Configure Monitoring**: Set up alerts and dashboards

## 📚 Documentation
- [API Documentation](api/README.md)
- [PWA Documentation](app/README.md)
- [Infrastructure Documentation](infra/README.md)

## 🧪 Testing

### API Testing
```bash
# Test health endpoint
curl http://localhost:8080/healthz

# Test verification endpoint
curl -H "Authorization: Bearer test-key" \
     -F "text=The Earth is round" \
     -F "mode=fast" \
     -F "language=en" \
     http://localhost:8080/v1/verify
```

### PWA Testing
1. Open http://localhost:3000
2. Test share functionality
3. Verify offline support
4. Check service worker

## 🔒 Security
- **API Keys**: Bearer token authentication
- **Service Accounts**: IAM-based permissions
- **Data Encryption**: All data encrypted at rest and in transit
- **PII Protection**: User data anonymized
- **Retention Policies**: Automatic data deletion

## 📊 Monitoring
- **Cloud Logging**: Application logs
- **Cloud Monitoring**: Metrics and alerting
- **BigQuery**: Analytics and reporting
- **Uptime Checks**: Service availability

## 🛠️ Development

### Project Structure
```
TruthLens/
├── app/                    # React PWA
│   ├── src/App.js          # Main React component
│   ├── src/App.css          # Styles
│   ├── public/index.html    # HTML template
│   ├── manifest.json        # PWA manifest
│   └── public/sw.js        # Service worker
├── api/                     # Python FastAPI
│   ├── main.py             # Main API application
│   ├── simple_main.py      # Simple development server
│   ├── requirements.txt    # Dependencies
│   └── Dockerfile          # Container config
├── infra/                   # Infrastructure
│   ├── terraform/          # Terraform configs
│   ├── cloudbuild.yaml     # CI/CD config
│   └── api-gateway.yaml    # API Gateway spec
└── scripts/                # Deployment scripts
    ├── deploy.sh           # Production deployment
    ├── setup-dev.sh        # Development setup
    └── start-dev.sh        # Start dev servers
```

### Adding Features
1. **API**: Add endpoints in `api/main.py`
2. **PWA**: Add components in `app/src/`
3. **Infrastructure**: Update Terraform configs
4. **Monitoring**: Add metrics and alerts

## 🤝 Contributing
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📄 License
MIT License - see LICENSE file for details

## 🆘 Support
- **Email**: support@truthlens.app
- **Documentation**: https://docs.truthlens.app
- **Issues**: https://github.com/channi23/OrangeLens/issues
- **Status**: https://status.truthlens.app

## 🗺️ Roadmap
- [ ] Mobile app (iOS/Android)
- [ ] Browser extension
- [ ] Telegram bot
- [ ] WhatsApp integration
- [ ] Advanced analytics
- [ ] Custom fact-check sources
- [ ] API rate limiting
- [ ] Multi-tenant support

---

**TruthLens** - Making fact verification accessible, transparent, and reliable. 🔍✨
